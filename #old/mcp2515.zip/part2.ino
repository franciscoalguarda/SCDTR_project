#include <SPI.h>
#include <mcp2515.h>

// Defines the CS pin for SPI
const int CAN_CS_PIN = 17; 
MCP2515* mcp2515;

// Luminaire identity
const int MY_NODE_ID = 2; 
// NETWORK STATE 
const int MAX_NODES = 3; // 3 luminaires max
float network_lux[MAX_NODES] = {0.0, 0.0, 0.0}; // Guarda o Lux: [Nó 1, Nó 2, Nó 3]

const int LED_PIN = 15;
const int DAC_RANGE = 4096;
float m = -1.0; 
float b = 6.75;  

float background_lux = 0;
float system_gain = 0.0; 

float setpoint = 5.0; // in lux

const float h = 0.01; // Sampling period of 10ms (100Hz) 

// State Variables (Interface)
bool feedback_enabled = true;    
bool anti_windup_enabled = true; 
bool stream_y = false;           
bool stream_u = false;           
float manual_pwm = 0;  // Duty-cycle value applied manually to the LED by the user       
float current_lux = 0;           
float current_u = 0;   // Current duty-cycle    
char current_occupancy = 'l'; // Can be 'o' (off), 'l' (low) or 'h' (high)       

bool stream_excel = false;

// Circular Buffer
const int buffer_size = 10;
float lux_buffer[buffer_size];
int buffer_idx = 0;

// 1-Minute history variables 
const int minute_buffer_size = 600; // 60 seconds * 10 samples/second
float history_y[minute_buffer_size];
float history_u[minute_buffer_size];
int history_idx = 0;
int history_counter = 0; // Counts cycles to record at 10Hz

// Performance metrics variables
float E_energy = 0;          // Energy Consumption (Joule)
float V_visibility_sum = 0;  // Visibility error sum
float F_flicker_sum = 0;     // Flicker sum
long metrics_count = 0;      // Number of samples (N)
float last_u_1 = 0;          // Duty cycle at k-1 (For flicker)
float last_u_2 = 0;          // Duty cycle at k-2 (For flicker)
float P_max = 0.05;          // Example: Max LED power (50mW) - Adjust according to the LED

// Variables for Jitter test
bool measure_jitter = false;
const int JITTER_SAMPLES = 100; // 100 samples = 1 second of data at 100Hz
unsigned long jitter_buffer[JITTER_SAMPLES];
int jitter_idx = 0;
unsigned long last_micros = 0;


// Prototypes
float getLux();
float getFilteredLux(float new_sample);
void calibrateGain();
float computePID(float ref, float y);
void processUI();
void updateMetrics(float u, float y, float ref);

void setup() {
  Serial.begin(115200);
  while (!Serial);

  SPI.begin();

  mcp2515 = new MCP2515(CAN_CS_PIN);

  mcp2515->reset(); 
  mcp2515->setBitrate(CAN_500KBPS, MCP_8MHZ); 
  mcp2515->setNormalMode();

  Serial.println("CAN-bus Initialized!");

  Serial.setTimeout(2); 

  analogReadResolution(12);
  analogWriteFreq(60000);      
  analogWriteRange(DAC_RANGE); 

  pinMode(LED_PIN, OUTPUT);
  analogWrite(LED_PIN, 0); 

  delay(2000); 

  // Initialize buffer and calculate background light
  float sum = 0;
  for(int j = 0; j < 50; j++) {
    float val = getLux();
    sum += val;
    for(int k=0; k<buffer_size; k++) lux_buffer[k] = val; // Fill buffer
    delay(5);
  }
  background_lux = sum / 50.0;

  Serial.print("Background LUX: ");
  Serial.println(background_lux); 

  printHelpMenu();
}

void printHelpMenu() {
  Serial.println("\n==================================================");
  Serial.println("                 COMMAND MENU                 ");
  Serial.println("==================================================");
  Serial.println("--- SET COMMANDS ---");
  Serial.println("  r 1 <val> : Set Setpoint (Ref) in LUX");
  Serial.println("  u 1 <val> : Set manual PWM (0-4095) [Requires f 1 0]");
  Serial.println("  f 1 <0/1> : Turn Feedback (PID) Off (0) or On (1)");
  Serial.println("  a 1 <0/1> : Turn Anti-Windup Off (0) or On (1)");
  Serial.println("  o 1 <val> : Set occupancy ('o'=off, 'l'=low, 'h'=high)");
  Serial.println("\n--- GET COMMANDS ---");
  Serial.println("  g r 1     : Get current Setpoint (Ref)");
  Serial.println("  g y 1     : Get current measured LUX (y)");
  Serial.println("  g u 1     : Get current Duty Cycle / PWM (u)");
  Serial.println("  g v 1     : Get LDR sensor Voltage (Volts)");
  Serial.println("  g d 1     : Get current External Illuminance (LUX)");
  Serial.println("  g p 1     : Get instantaneous LED Power (Watts)");
  Serial.println("  g t 1     : Get Time since last restart (Seconds)");
  Serial.println("  g o 1     : Get current occupancy state");
  Serial.println("  g f 1     : Get Feedback state (1=On)");
  Serial.println("  g a 1     : Get Anti-Windup state (1=On)");
  Serial.println("\n--- PERFORMANCE METRICS ---");
  Serial.println("  g E 1     : Get Accumulated Energy Consumption (J)");
  Serial.println("  g V 1     : Get Mean Visibility Error (LUX)");
  Serial.println("  g F 1     : Get Mean Flicker Error (s^-1)");
  Serial.println("  R         : Restart PID and Metrics");
  Serial.println("\n--- PLOTS (Stream Serial Plotter) ---");
  Serial.println("  s y 1     : Start LUX stream (lowercase)");
  Serial.println("  S y 1     : Stop LUX stream (uppercase)");
  Serial.println("  s u 1     : Start PWM stream");
  Serial.println("  S u 1     : Stop PWM stream");
  Serial.println("\n--- EXTRA SHORTCUTS ---");
  Serial.println("  p <val>   : Change Kp");
  Serial.println("  i <val>   : Change Ki");
  Serial.println("  d <val>   : Change Kd");
  Serial.println("  c         : Run Static Gain Calibration");
  Serial.println("  j         : Run Jitter test (Sampling)");
  Serial.println("  l         : Run linearity test");
  Serial.println("  x         : Run Stream for Excel plot");
  Serial.println("  z         : Get LDR resistance value");
  
  Serial.println("==================================================\n");
}

class PIDController {
  private:
    float Kp, Ki, Kd;
    float b_weight;
    float i_term, last_error;
    float h;

  public:

    PIDController(float p, float i, float d, float bw) {
      Kp = p; Ki = i; Kd = d; b_weight = bw; 
      i_term = 0; last_error = 0;
      h = ::h; // "::" tells C++ to fetch the global 'h';
    }

    // Control Function
    float compute(float ref, float y, bool antiwindup_control) {
      
      // Error Calculation with Set-point Weighting 
      // error_p is used only in the Proportional term to smooth abrupt changes
      float error_p = b_weight * ref - y; 
      float error = ref - y; // Real error for Integral and Derivative terms
      
      // Proportional Term 
      float p_term = Kp * error_p;
      
      // Integral Term (Euler Integration)
      i_term += Ki * error * h; 
      
      // Derivative Term 
      float d_term = Kd * (error - last_error) / h;
      last_error = error;

      float u = p_term + i_term + d_term;

      // Anti-Windup
      if (u > 4095) {
          u = 4095;
          // Only stops integration if the error is positive (requesting more than maximum)
          if (error > 0) {
              i_term -= Ki * error * h; 
          }
      } 
      else if (u < 0) {
          u = 0;
          // Only stops integration if the error is negative (requesting less than zero)
          if (error < 0) {
              i_term -= Ki * error * h; 
          }
      }
      
      return u;
    }

    // Setters for the User Interface (Tuning)
    void setKp(float p) { Kp = p; }
    void setKi(float i) { Ki = i; }
    void setKd(float d) { Kd = d; }
    void reset() { i_term = 0; last_error = 0; }
};

PIDController myPID(80.0, 400.0, 0.0, 0.5); // Creates luminaire 1


float getFilteredLux(float new_sample) {
  lux_buffer[buffer_idx] = new_sample;
  buffer_idx = (buffer_idx + 1) % buffer_size; 
  
  float sum = 0;
  for(int j = 0; j < buffer_size; j++) sum += lux_buffer[j];
  return sum / (float)buffer_size;
}

float getLux() {
  float adc_sum = 0;
  for(int j = 0; j < 10; j++) {
    adc_sum += analogRead(A0);
    delayMicroseconds(500);
  }
  float read_adc = adc_sum / 10.0;
  if (read_adc == 0) read_adc = 1;

  float R_LDR = 40950000.0 / (float)read_adc - 10000.0;
  float logR = log10(R_LDR);
  return pow(10, (logR - b) / m);
}

void calibrateGain() {
  Serial.println("u (DutyCycle), y (LUX), G_inst (Gain)"); 
  float sum_G = 0;
  int count = 0;

  for (int u_val = 256; u_val <= 4096; u_val += 512) {
    int val = (u_val > 4095) ? 4095 : u_val;
    analogWrite(LED_PIN, val);
    delay(2000); 
    
    float current_y = getLux();
    float G_inst = (current_y - background_lux) / (float)val;
    
    Serial.print(val); Serial.print(", ");
    Serial.print(current_y); Serial.print(", ");
    Serial.println(G_inst, 6);

    sum_G += G_inst;
    count++;
  }
  
  float G_geral = sum_G / count;
  system_gain = G_geral;
  Serial.print("Overall Gain (Mean): ");
  Serial.println(G_geral, 6); 
  analogWrite(LED_PIN, 0);
  delay(1000);
}


void updateMetrics(float u, float y, float ref) {
    float d_k = u / 4095.0; // Converts duty cycle from 0-4095 to 0.0-1.0
    
    // Energy
    E_energy += P_max * d_k * h;

    // Visibility
    if (y < ref) {
        V_visibility_sum += (ref - y);
    }

    // Flicker -- Analyze
    float diff1 = d_k - last_u_1;
    float diff2 = last_u_1 - last_u_2;
    if (diff1 * diff2 < 0) {
        F_flicker_sum += (abs(diff1) + abs(diff2));
    }
    
    last_u_2 = last_u_1;
    last_u_1 = d_k;
    metrics_count++;
}

void processUI() {
  if (Serial.available() > 0) {
    
    String input = Serial.readStringUntil('\n');
    input.trim(); 
    if (input.length() == 0) return;

    char cmd = input.charAt(0);

    // Prints the command menu
    if (cmd == 'h' || cmd == '?') {
      printHelpMenu();
      return;
    }

    // 'GET' COMMANDS (Tables 1 and 2)
    if (cmd == 'g') {
      char subcmd = input.charAt(2);
      
      switch (subcmd) {
        case 'u': Serial.print("u 1 "); Serial.print(current_u); Serial.print("("); Serial.print((current_u / 4095.0) * 100.0);Serial.print("%"); Serial.println(")"); break;
        case 'r': Serial.print("r 1 "); Serial.println(setpoint); break;
        case 'y': Serial.print("y 1 "); Serial.println(current_lux); break;
        case 'a': Serial.print("a 1 "); Serial.println(anti_windup_enabled); break;
        case 'f': Serial.print("f 1 "); Serial.println(feedback_enabled); break;
        case 'o': Serial.print("o 1 "); Serial.println(current_occupancy); break;
      
        case 'v': // Measure LDR voltage 
          {
          float voltage = (analogRead(A0) / 4095.0) * 3.3; 
          Serial.print("v 1 "); Serial.println(voltage, 3);
          }
          break;
          
        case 't': // Time since last restart 
          Serial.print("t 1 "); Serial.println(millis() / 1000.0); 
          break;
          
        case 'd': // External Illuminance (background)
          Serial.print("d 1 "); Serial.println(background_lux); 
          break;
          
        case 'p': // Instantaneous Power in Watts 
          Serial.print("p 1 "); Serial.println(P_max * (current_u / 4095.0), 4); 
          break;

        case 'b': // Last minute buffer 
          {
            char var = input.charAt(4); // 'y' or 'u'
            Serial.print("b "); Serial.print(var); Serial.print(" 1 ");
            for (int j = 0; j < minute_buffer_size; j++) {
              int read_idx = (history_idx + j) % minute_buffer_size;
              if (var == 'y') Serial.print(history_y[read_idx]);
              else if (var == 'u') Serial.print(history_u[read_idx]);
              if (j < minute_buffer_size - 1) Serial.print(", ");
            }
            Serial.println();
          }
          break;

        // Performance Metrics 
        case 'E': 
          Serial.print("E 1 "); Serial.println(E_energy, 4); 
          break;

        case 'V': 
          if(metrics_count > 0) {
             Serial.print("V 1 "); Serial.println(V_visibility_sum / metrics_count, 4); 
          } else { Serial.println("V 1 0.0000"); }
          break;

        case 'F': 
          if(metrics_count > 0) {
             Serial.print("F 1 "); Serial.println(F_flicker_sum / metrics_count, 4); 
          } else { Serial.println("F 1 0.0000"); }
          break;
          
        default: 
          Serial.println("err"); 
          break;
      }
      return;
    }

    // STREAM COMMANDS (s/S)  
    if (cmd == 's' || cmd == 'S') {
      char var = input.charAt(2);
      bool state = (cmd == 's'); 
      if (var == 'y') stream_y = state;
      else if (var == 'u') stream_u = state;
      Serial.println("ack");
      return;
    }

    // Excel stream
    if (cmd == 'x') {
      stream_excel = !stream_excel; 
      if(stream_excel) {
        // Excel Header (SI Units as requested in the guide)
        Serial.println("Time(s),Ref(LUX),Measured(LUX),Duty-Cycle(%)"); 
      } else {
        Serial.println("ack");
      }
      return;
    }

    if (cmd == 'j') { 
        measure_jitter = true;
        jitter_idx = 0;
        last_micros = micros(); // Record start time
        Serial.println("Measuring jitter... wait 1 second.");
        return;
    }

    if (cmd == 'l') { 
        runLinearitySweep(); 
    }

    if (cmd == 'z') { // Command to read Resistance
        int adc_raw = analogRead(A0); // Replace A0 with your LDR pin
        float R_fixed = 10000.0;      
    
        if (adc_raw > 0) {
            float R_ldr = R_fixed * (4095.0 / (float)adc_raw - 1.0);
            Serial.print("ADC Raw: "); Serial.print(adc_raw);
            Serial.print(" | R_LDR: "); Serial.print(R_ldr);
            Serial.println(" Ohms");
        } else {
            Serial.println("Error: ADC read 0 (possible short circuit to GND)");
        }
      
      }

    // RESTART COMMAND (R) 
    if (cmd == 'R') {
      myPID.reset(); // Call to class method
      E_energy = 0; V_visibility_sum = 0; F_flicker_sum = 0; metrics_count = 0;
      Serial.println("ack");
      return;
    }

    // SET AND TUNING COMMANDS
    int firstSpace = input.indexOf(' ');
    int secondSpace = input.indexOf(' ', firstSpace + 1);

    // Gain Tuning 
    if (secondSpace == -1 && firstSpace != -1) {
      float val = input.substring(firstSpace + 1).toFloat();
      switch(cmd) {
        case 'p': myPID.setKp(val); Serial.println("ack"); break;
        case 'i': myPID.setKi(val); Serial.println("ack"); break;
        case 'd': myPID.setKd(val); Serial.println("ack"); break;
        case 'm': m = val; Serial.println("ack"); break;
        default: Serial.println("err"); break;
      }
      return;
    } 

    // Set Commands (Tables 1 and 3)
    if (secondSpace != -1) {
      float val = input.substring(secondSpace + 1).toFloat();

      switch (cmd) {
        case 'r': // Setpoint in LUX
          setpoint = val;
          Serial.println("ack");
          break;
        case 'u': // Manual Duty Cycle (Turns PID off)
          manual_pwm = (val / 100.0) * 4095.0;
          feedback_enabled = false;
          Serial.println("ack");
          break;
        case 'f': // Feedback ON/OFF 
          feedback_enabled = (val > 0);
          if(!feedback_enabled) manual_pwm = current_u; 
          Serial.println("ack");
          break;
        case 'a': // Anti-Windup ON/OFF 
          anti_windup_enabled = (val > 0);
          Serial.println("ack");
          break;
        case 'o': // Occupancy State 
          current_occupancy = input.charAt(secondSpace + 1);
          Serial.println("ack");
          break;
        default: Serial.println("err"); break;
      }
    } else if (cmd == 'c') { // Gain Calibration 
      calibrateGain();
    } else {
      Serial.println("err");
    }
  }
}


// ask if we should leave the plot functions

void runLinearitySweep() {
  feedback_enabled = false; // Important: Turn off PID to prevent interference
  Serial.println("Duty_Cycle(%),Measured_Lux");
  
  for (int p = 0; p <= 100; p += 10) {
    // Convert percentage to 12-bit scale (0-4095)
    int pwm_value = (p / 100.0) * 4095;
    analogWrite(LED_PIN, pwm_value); 
    
    delay(2000); 
    
    // Read value (use your lux variable already calculated in the loop)
    float current_lux = getLux(); 
    
    Serial.print(p);
    Serial.print(",");
    Serial.println(current_lux);
  }
  
  analogWrite(LED_PIN, 0); // Turn off at the end
  feedback_enabled = true; // Turn PID back on
  Serial.println("Sweep Done. Send 'R' to resume.");
}


void sendCANMessage(float lux_to_send) {
  struct can_frame canMsg;
  canMsg.can_id  = MY_NODE_ID; // Sender ID
  canMsg.can_dlc = 4; // Payload size (4 bytes for a float)

  // C++ trick to convert the float in 4 bytes and send
  unsigned char* bytes = (unsigned char*)&lux_to_send;
  for(int i = 0; i < 4; i++) {
    canMsg.data[i] = bytes[i];
  }

  mcp2515->sendMessage(&canMsg);
  // Serial.println("CAN message sent!"); 
}

void readCANMessages() {
  struct can_frame canMsg;
  
  // Verifies if theres any new messages in the buffer
  if (mcp2515->readMessage(&canMsg) == MCP2515::ERROR_OK) {
    
    // If there's something, reads it
    int sender_id = canMsg.can_id;
    
    // Rebuilds the float from the 4 bytes 
    float received_lux;
    unsigned char* p = (unsigned char*)&received_lux;
    for(int i = 0; i < 4; i++) {
      p[i] = canMsg.data[i];
    }

    Serial.print("CAN RX | Node: ");
    Serial.print(sender_id);
    Serial.print(" | Lux: ");
    Serial.println(received_lux);
  }
}



void loop() {
  static unsigned long last_t = millis();
  processUI(); 

  if (millis() - last_t >= 10) { 
    readCANMessages();
    last_t += 10;

    // ==========================================
    // START OF JITTER MEASUREMENT BLOCK
    // ==========================================
    unsigned long current_micros = micros();
    
    if (measure_jitter) {
      if (jitter_idx < JITTER_SAMPLES) {
        if (jitter_idx > 0) {
          // Calculate time passed since last execution
          jitter_buffer[jitter_idx] = current_micros - last_micros;
        } else {
          jitter_buffer[0] = 10000; // First sample is discarded
        }
        jitter_idx++;
      } else {
        measure_jitter = false; // Stop measuring
        
        // Print results in Excel format (CSV)
        Serial.println("Sample,Real_Period(us),Jitter_Error(us)");
        for (int i = 1; i < JITTER_SAMPLES; i++) {
          long erro_jitter = (long)jitter_buffer[i] - 10000; // Deviation from the ideal 10000us
          Serial.print(i); Serial.print(",");
          Serial.print(jitter_buffer[i]); Serial.print(",");
          Serial.println(erro_jitter);
        }
        Serial.println("Jitter test completed.");
      }
    }
    last_micros = current_micros;
    // ==========================================
    // END OF JITTER MEASUREMENT BLOCK
    // ==========================================



    current_lux = getFilteredLux(getLux());

    if (feedback_enabled) {
      
      current_u = myPID.compute(setpoint, current_lux, anti_windup_enabled);
    } else {
      current_u = manual_pwm;

    
    }

    // excel stream
    if (stream_excel) {
      Serial.print(millis() / 1000.0, 3); Serial.print(","); // Time in seconds 
      Serial.print(setpoint);             Serial.print(","); // Reference (L) 
      Serial.print(current_lux);          Serial.print(","); // Measurement (l) 
      Serial.println((current_u / 4095.0) * 100.0, 4);                 // Normalized control (d) 
    }
    
    analogWrite(LED_PIN, (int)current_u);
    updateMetrics(current_u, current_lux, setpoint);

    if (stream_y) {
      Serial.print("s y 1 "); Serial.print(current_lux); Serial.print(" "); Serial.println(millis());
    }
    if (stream_u) {
      Serial.print("s u 1 "); Serial.print(current_u); Serial.print(" "); Serial.println(millis());
    }

    // History recording (10Hz)
    history_counter++;
    if (history_counter >= 10) {
      history_y[history_idx] = current_lux;
      history_u[history_idx] = current_u;
      history_idx = (history_idx + 1) % minute_buffer_size;

      sendCANMessage(current_lux);

      history_counter = 0;

    }
  }

  // Theoretical LUX prediction based on model
  float lux_predicted = (system_gain * current_u) + background_lux;

}